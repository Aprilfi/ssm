CREATE PROCEDURE deptyearsalary(IN deptid INT, OUT deptsy INT)
  BEGIN
     SELECT salary*12 FROM dept WHERE id=deptid INTO deptsy;
END;

